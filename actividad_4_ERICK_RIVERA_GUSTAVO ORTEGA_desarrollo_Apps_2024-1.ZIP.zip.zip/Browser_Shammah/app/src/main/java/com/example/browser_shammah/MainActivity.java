package com.example.browser_shammah;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {


    private EditText et1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Inicializamos

        et1 = (EditText)findViewById(R.id.et_buscador);
    }

    //Creamos el metodo del boton

    public void Navegador(View view){

        //usamos el objeto Intent
        Intent intent = new Intent(packageContext: this, VisorWeb.class);
        intent.putExtra(name: "nombreSitio", et1.getText().toString());
        startActivity(intent);

    }
}