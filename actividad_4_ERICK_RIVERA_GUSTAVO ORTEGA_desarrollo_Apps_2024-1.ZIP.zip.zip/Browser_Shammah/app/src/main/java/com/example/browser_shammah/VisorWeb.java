package com.example.browser_shammah;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class VisorWeb extends AppCompatActivity {

    WebView visor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visor_web);

        //Haceos la inicializacion

        visor = (WebView)findViewById(R.id.visor1);

        String URL = getIntent().getStringExtra(name: "nombreSitio");
        //Usamos el cliente web

        visor.setWebViewClient(new WebViewClient());
        visor.loadUrl("http://"+ URL);

    }
    //Creamos el metodo para el boton
    public void regresar(View view) {
        Intent intent = new Intent(packageContext:this, MainActivity.class);
        //Lo inicializamos
        startActivity(intent);
    }
}